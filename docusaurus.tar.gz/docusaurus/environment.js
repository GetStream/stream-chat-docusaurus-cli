module.exports = {
  // Read-only API key: it doesnt make sense to use env vars for this
  // while we are still keeping the zipped file on the repo
  algoliaApiKey: 'fd1b03de28081b5aa29dbccced4620b9',
  algoliaAppId: '7RY30ISS74',
};
