/* eslint-disable no-undef */
/** @type {import('@docusaurus/types').DocusaurusConfig} */

const fs = require('fs');
const path = require('path');

// const STREAM_SDK_DOCUSAURUS_PATH = `${
//   process.env['STREAM_SDK_PATH'] || '..'
// }/docusaurus`;
const STREAM_SDK_DOCUSAURUS_PATH = '../docusaurus';

const CUSTOM_PLUGIN_REGEX = /^docusaurus.*\.plugin.js$/;

const DOCUSAURUS_DIR = fs.readdirSync(STREAM_SDK_DOCUSAURUS_PATH);
const DOCS_DIR = fs.readdirSync(`${STREAM_SDK_DOCUSAURUS_PATH}/docs`);

const SDK_FOLDERS = DOCS_DIR.filter((file) =>
  fs.lstatSync(`${STREAM_SDK_DOCUSAURUS_PATH}/docs/${file}`).isDirectory()
);

const CUSTOM_PLUGIN_FILES = DOCUSAURUS_DIR.filter((file) =>
  CUSTOM_PLUGIN_REGEX.test(file)
);

const CUSTOM_PLUGINS = CUSTOM_PLUGIN_FILES.map((file) => {
  const sdkConfig = require(path.join(STREAM_SDK_DOCUSAURUS_PATH, file));
  return sdkConfig.plugins;
}).flat();

const defaultPlugins = SDK_FOLDERS.map((SDK) => [
  '@docusaurus/plugin-content-docs',
  {
    id: SDK.replace(' ', ''),
    path: `${STREAM_SDK_DOCUSAURUS_PATH}/docs/${SDK}`,
    routeBasePath: `chat/docs/sdk/${SDK}`,
    ...(fs.existsSync(
      `${STREAM_SDK_DOCUSAURUS_PATH}/sidebars${SDK.replace(' ', '')}.json`
    )
      ? {
          sidebarPath: require.resolve(
            `${STREAM_SDK_DOCUSAURUS_PATH}/sidebars${SDK.replace(' ', '')}.json`
          ),
        }
      : {}),
  },
]);

const navbarSDKItems = SDK_FOLDERS.map((SDK) => ({
  label: SDK,
  to: `/chat/docs/sdk/${SDK}`,
  type: 'doc',
}));

const navbarVersionItems = SDK_FOLDERS.map((SDK) => ({
  docsPluginId: SDK.replace(' ', ''),
  type: 'docsVersionDropdown',
}));

module.exports = {
  baseUrl: '/',
  favicon: 'https://getstream.imgix.net/images/favicons/favicon-96x96.png',
  onBrokenLinks: 'warn',
  onBrokenMarkdownLinks: 'warn',
  organizationName: 'GetStream',
  plugins: [
    ...defaultPlugins,
    ...CUSTOM_PLUGINS,
    '@docusaurus/plugin-content-pages',
    path.resolve(__dirname, 'src/stream-layout-fetch'),
    path.resolve(__dirname, 'src/symlink-docusaurus'),
  ],
  projectName: 'stream-chat',
  tagline: 'Stream Chat official SDKs',
  themeConfig: {
    colorMode: {
      disableSwitch: true,
    },
    footer: {
      copyright: '© Stream.IO, Inc. All Rights Reserved.',
      links: [
        {
          items: [
            {
              href: 'https://twitter.com/getstream_io',
              label: 'Twitter',
            },
          ],
          title: 'Community',
        },
        {
          items: [
            {
              href: 'https://github.com/GetStream',
              label: 'GitHub',
            },
          ],
          title: 'More',
        },
      ],
      style: 'dark',
    },
    liveCodeBlock: {
      playgroundPosition: 'bottom',
    },
    navbar: {
      items: [
        {
          href: 'https://github.com/GetStream',
          label: 'GitHub',
          position: 'right',
        },
        {
          items: navbarSDKItems,
          label: 'SDK',
          position: 'left',
        },
        ...navbarVersionItems,
      ],
      // logo: {
      //   alt: 'Stream Logo',
      //   src: 'img/logo.svg',
      // },
      // title: 'Stream Chat',
    },
  },
  themes: ['@docusaurus/theme-classic', '@docusaurus/theme-live-codeblock'],
  title: 'Stream Chat - Docs',
  url: 'https://getstream.io/chat/docs/sdk',
};
