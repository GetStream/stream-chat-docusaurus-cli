
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';
export default [
{
  path: '/chat/docs/sdk/',
  component: ComponentCreator('/chat/docs/sdk/','981'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative',
  component: ComponentCreator('/chat/docs/sdk/reactnative','4ec'),
  
  routes: [
{
  path: '/chat/docs/sdk/reactnative/',
  component: ComponentCreator('/chat/docs/sdk/reactnative/','b46'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/client',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/client','2f8'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/hello_stream_chat',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/hello_stream_chat','8da'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/stream_chat_with_navigation',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/stream_chat_with_navigation','47b'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/translations',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/translations','935'),
  exact: true,
},
]
},
{
  path: '*',
  component: ComponentCreator('*')
}
];
