
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';
export default [
{
  path: '/chat/docs/sdk/',
  component: ComponentCreator('/chat/docs/sdk/','981'),
  exact: true,
},
{
  path: '/chat/docs/sdk/search',
  component: ComponentCreator('/chat/docs/sdk/search','586'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android',
  component: ComponentCreator('/chat/docs/sdk/android','9e5'),
  
  routes: [
{
  path: '/chat/docs/sdk/android/',
  component: ComponentCreator('/chat/docs/sdk/android/','023'),
  exact: true,
},
]
},
{
  path: '/chat/docs/sdk/flutter',
  component: ComponentCreator('/chat/docs/sdk/flutter','411'),
  
  routes: [
{
  path: '/chat/docs/sdk/flutter/',
  component: ComponentCreator('/chat/docs/sdk/flutter/','646'),
  exact: true,
},
]
},
{
  path: '/chat/docs/sdk/ios',
  component: ComponentCreator('/chat/docs/sdk/ios','beb'),
  
  routes: [
{
  path: '/chat/docs/sdk/ios/',
  component: ComponentCreator('/chat/docs/sdk/ios/','d8a'),
  exact: true,
},
]
},
{
  path: '/chat/docs/sdk/react',
  component: ComponentCreator('/chat/docs/sdk/react','798'),
  
  routes: [
{
  path: '/chat/docs/sdk/react/',
  component: ComponentCreator('/chat/docs/sdk/react/','98c'),
  exact: true,
},
]
},
{
  path: '/chat/docs/sdk/reactnative',
  component: ComponentCreator('/chat/docs/sdk/reactnative','771'),
  
  routes: [
{
  path: '/chat/docs/sdk/reactnative/',
  component: ComponentCreator('/chat/docs/sdk/reactnative/','92e'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/client',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/client','222'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/hello_stream_chat',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/hello_stream_chat','123'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/stream_chat_with_navigation',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/stream_chat_with_navigation','b3d'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/translations',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/translations','604'),
  exact: true,
},
]
},
{
  path: '*',
  component: ComponentCreator('*')
}
];
