
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/chat/docs/sdk/search/',
    component: ComponentCreator('/chat/docs/sdk/search/','9d6'),
    exact: true
  },
  {
    path: '/chat/docs/sdk/react/',
    component: ComponentCreator('/chat/docs/sdk/react/','2e1'),
    routes: [
      {
        path: '/chat/docs/sdk/react/',
        component: ComponentCreator('/chat/docs/sdk/react/','a7a'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/basics/getting_started/',
        component: ComponentCreator('/chat/docs/sdk/react/basics/getting_started/','644'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/channel_action_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/channel_action_context/','e85'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/channel_state_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/channel_state_context/','130'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/chat_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/chat_context/','679'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/component_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/component_context/','425'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/emoji_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/emoji_context/','c6b'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/message_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/message_context/','e96'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/message_input_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/message_input_context/','cdf'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/translation_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/translation_context/','30e'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/contexts/typing_context/',
        component: ComponentCreator('/chat/docs/sdk/react/contexts/typing_context/','412'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/core-components/channel_list/',
        component: ComponentCreator('/chat/docs/sdk/react/core-components/channel_list/','cee'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/core-components/channel/',
        component: ComponentCreator('/chat/docs/sdk/react/core-components/channel/','2aa'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/core-components/chat/',
        component: ComponentCreator('/chat/docs/sdk/react/core-components/chat/','826'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/core-components/message_list/',
        component: ComponentCreator('/chat/docs/sdk/react/core-components/message_list/','358'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/core-components/thread/',
        component: ComponentCreator('/chat/docs/sdk/react/core-components/thread/','d1b'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/core-components/virtualized_list/',
        component: ComponentCreator('/chat/docs/sdk/react/core-components/virtualized_list/','f6d'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/adding_messagelist_notification/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/adding_messagelist_notification/','db2'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/attachment_actions/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/attachment_actions/','478'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/channel_header/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/channel_header/','cde'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/channel_list_preview/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/channel_list_preview/','365'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/channel_search/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/channel_search/','27a'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/channel-list-infinite-scroll/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/channel-list-infinite-scroll/','3c8'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/channel-user-lists/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/channel-user-lists/','719'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/connection_status/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/connection_status/','dad'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/emoji_picker/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/emoji_picker/','278'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/geolocation_attachment/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/geolocation_attachment/','2da'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/giphy_preview/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/giphy_preview/','184'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/image_gallery/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/image_gallery/','4dc'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/livestream-setup/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/livestream-setup/','83c'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/mentions_actions/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/mentions_actions/','6d8'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/message_actions/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/message_actions/','0e7'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/multiple_channel_lists/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/multiple_channel_lists/','e45'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/override_submit_handler/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/override_submit_handler/','de7'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/pin_indicator/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/pin_indicator/','2c4'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/reactions/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/reactions/','b4d'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/suggestion_list/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/suggestion_list/','c9e'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/system_message/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/system_message/','666'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/thread_header/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/thread_header/','edb'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/typing_indicator/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/typing_indicator/','28f'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/custom-code-examples/video-integration-100ms/',
        component: ComponentCreator('/chat/docs/sdk/react/custom-code-examples/video-integration-100ms/','913'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/customization/css_and_theming/',
        component: ComponentCreator('/chat/docs/sdk/react/customization/css_and_theming/','82c'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/customization/input_ui/',
        component: ComponentCreator('/chat/docs/sdk/react/customization/input_ui/','85b'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/customization/message_ui/',
        component: ComponentCreator('/chat/docs/sdk/react/customization/message_ui/','a71'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/customization/translations/',
        component: ComponentCreator('/chat/docs/sdk/react/customization/translations/','aaa'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/customization/typescript_and_generics/',
        component: ComponentCreator('/chat/docs/sdk/react/customization/typescript_and_generics/','5a2'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/hooks/channel_list_hooks/',
        component: ComponentCreator('/chat/docs/sdk/react/hooks/channel_list_hooks/','163'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/hooks/message_hooks/',
        component: ComponentCreator('/chat/docs/sdk/react/hooks/message_hooks/','764'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/hooks/message_input_hooks/',
        component: ComponentCreator('/chat/docs/sdk/react/hooks/message_input_hooks/','7ca'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/hooks/message_list_hooks/',
        component: ComponentCreator('/chat/docs/sdk/react/hooks/message_list_hooks/','f48'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/message-components/attachment/',
        component: ComponentCreator('/chat/docs/sdk/react/message-components/attachment/','7f2'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/message-components/message_ui/',
        component: ComponentCreator('/chat/docs/sdk/react/message-components/message_ui/','17b'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/message-components/message/',
        component: ComponentCreator('/chat/docs/sdk/react/message-components/message/','ddb'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/message-components/reactions/',
        component: ComponentCreator('/chat/docs/sdk/react/message-components/reactions/','c44'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/message-components/ui-components/',
        component: ComponentCreator('/chat/docs/sdk/react/message-components/ui-components/','520'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/message-input-components/input_ui/',
        component: ComponentCreator('/chat/docs/sdk/react/message-input-components/input_ui/','4bf'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/message-input-components/message_input/',
        component: ComponentCreator('/chat/docs/sdk/react/message-input-components/message_input/','b75'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/message-input-components/ui_components/',
        component: ComponentCreator('/chat/docs/sdk/react/message-input-components/ui_components/','367'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/release-guides/upgrade-to-v10/',
        component: ComponentCreator('/chat/docs/sdk/react/release-guides/upgrade-to-v10/','8fe'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/resources/',
        component: ComponentCreator('/chat/docs/sdk/react/resources/','ee2'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/troubleshooting/',
        component: ComponentCreator('/chat/docs/sdk/react/troubleshooting/','16f'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/utility-components/avatar/',
        component: ComponentCreator('/chat/docs/sdk/react/utility-components/avatar/','ecd'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/utility-components/channel_header/',
        component: ComponentCreator('/chat/docs/sdk/react/utility-components/channel_header/','20e'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/utility-components/channel_preview_ui/',
        component: ComponentCreator('/chat/docs/sdk/react/utility-components/channel_preview_ui/','89e'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/utility-components/channel_preview/',
        component: ComponentCreator('/chat/docs/sdk/react/utility-components/channel_preview/','309'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/utility-components/channel_search/',
        component: ComponentCreator('/chat/docs/sdk/react/utility-components/channel_search/','92c'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/utility-components/date_separator/',
        component: ComponentCreator('/chat/docs/sdk/react/utility-components/date_separator/','ee1'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/utility-components/indicators/',
        component: ComponentCreator('/chat/docs/sdk/react/utility-components/indicators/','b59'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/react/utility-components/window/',
        component: ComponentCreator('/chat/docs/sdk/react/utility-components/window/','24e'),
        exact: true,
        'sidebar': "defaultSidebar"
      }
    ]
  },
  {
    path: '/chat/docs/sdk/',
    component: ComponentCreator('/chat/docs/sdk/','981'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*')
  }
];
