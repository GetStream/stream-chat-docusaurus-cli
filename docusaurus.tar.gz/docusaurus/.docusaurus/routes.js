
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/chat/docs/sdk/',
    component: ComponentCreator('/chat/docs/sdk/','981'),
    exact: true
  },
  {
    path: '/chat/docs/sdk/angular/tags/',
    component: ComponentCreator('/chat/docs/sdk/angular/tags/','e21'),
    exact: true
  },
  {
    path: '/chat/docs/sdk/search/',
    component: ComponentCreator('/chat/docs/sdk/search/','e4d'),
    exact: true
  },
  {
    path: '/chat/docs/sdk/angular/',
    component: ComponentCreator('/chat/docs/sdk/angular/','0ad'),
    routes: [
      {
        path: '/chat/docs/sdk/angular/',
        component: ComponentCreator('/chat/docs/sdk/angular/','2d7'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/basics/getting_started/',
        component: ComponentCreator('/chat/docs/sdk/angular/basics/getting_started/','35e'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/attachment-list/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/attachment-list/','f42'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/avatar/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/avatar/','aa4'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/channel_list/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/channel_list/','f04'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/channel-preview/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/channel-preview/','5e2'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/icon/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/icon/','02c'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/loading-indicator/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/loading-indicator/','36e'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/message_list/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/message_list/','aa5'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/message-actions/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/message-actions/','06f'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/message-input/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/message-input/','edd'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/message-reactions/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/message-reactions/','a3f'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/message/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/message/','4b2'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/components/notifications/',
        component: ComponentCreator('/chat/docs/sdk/angular/components/notifications/','22d'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/concepts/themeing/',
        component: ComponentCreator('/chat/docs/sdk/angular/concepts/themeing/','f75'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/concepts/translation/',
        component: ComponentCreator('/chat/docs/sdk/angular/concepts/translation/','6b5'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/services/channel/',
        component: ComponentCreator('/chat/docs/sdk/angular/services/channel/','704'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/services/chat-client/',
        component: ComponentCreator('/chat/docs/sdk/angular/services/chat-client/','f72'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/services/notifications/',
        component: ComponentCreator('/chat/docs/sdk/angular/services/notifications/','e17'),
        exact: true,
        'sidebar': "defaultSidebar"
      },
      {
        path: '/chat/docs/sdk/angular/types/stream-message/',
        component: ComponentCreator('/chat/docs/sdk/angular/types/stream-message/','bd0'),
        exact: true,
        'sidebar': "defaultSidebar"
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*')
  }
];
