
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';
export default [
{
  path: '/chat/docs/sdk/',
  component: ComponentCreator('/chat/docs/sdk/','981'),
  exact: true,
},
{
  path: '/chat/docs/sdk/search',
  component: ComponentCreator('/chat/docs/sdk/search','586'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android',
  component: ComponentCreator('/chat/docs/sdk/android','ef1'),
  
  routes: [
{
  path: '/chat/docs/sdk/android/',
  component: ComponentCreator('/chat/docs/sdk/android/','41b'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/chanelInvites',
  component: ComponentCreator('/chat/docs/sdk/android/client/chanelInvites','2c0'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientChannelMembers',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientChannelMembers','8db'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientCreatingChannels',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientCreatingChannels','3d5'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientDeletingAndHidingChannel',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientDeletingAndHidingChannel','957'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientMessages',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientMessages','8a8'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientModerationTools',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientModerationTools','698'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientMutingChannels',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientMutingChannels','4ca'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientPinnedMessages',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientPinnedMessages','500'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientReactions',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientReactions','58a'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientReactions',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientReactions','594'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientSdkCallingSdkMethods',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientSdkCallingSdkMethods','5d6'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientSdkQueryingChannels',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientSdkQueryingChannels','427'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientSdkQueryingUsers',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientSdkQueryingUsers','882'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientSearchingMessages',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientSearchingMessages','2c3'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientSilentMessages',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientSilentMessages','a00'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientSlowMode',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientSlowMode','c97'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientThreadAndReplies',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientThreadAndReplies','3cd'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientTypingIndicators',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientTypingIndicators','d0b'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientUpdatingAChannel',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientUpdatingAChannel','9ea'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientUploadingFiles',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientUploadingFiles','108'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientUserPresence',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientUserPresence','25f'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientUserTypes',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientUserTypes','949'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/clientWatchingChannel',
  component: ComponentCreator('/chat/docs/sdk/android/client/clientWatchingChannel','edf'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/setup/clientAddingDependencies',
  component: ComponentCreator('/chat/docs/sdk/android/client/setup/clientAddingDependencies','671'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/setup/clientConnectingUser',
  component: ComponentCreator('/chat/docs/sdk/android/client/setup/clientConnectingUser','a7b'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/setup/clientInitializingSDK',
  component: ComponentCreator('/chat/docs/sdk/android/client/setup/clientInitializingSDK','bc8'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/client/setup/clientLogging',
  component: ComponentCreator('/chat/docs/sdk/android/client/setup/clientLogging','6d4'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/offline/offlineSetup',
  component: ComponentCreator('/chat/docs/sdk/android/offline/offlineSetup','3d6'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/channel_list/customizations/uiChannelListChangingChannelListViewComponents',
  component: ComponentCreator('/chat/docs/sdk/android/ui/channel_list/customizations/uiChannelListChangingChannelListViewComponents','ebe'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/channel_list/customizations/uiChannelListCreatingCustomViewHolderFactory',
  component: ComponentCreator('/chat/docs/sdk/android/ui/channel_list/customizations/uiChannelListCreatingCustomViewHolderFactory','530'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/channel_list/customizations/uiChannelListCustomizationsChangingStyle',
  component: ComponentCreator('/chat/docs/sdk/android/ui/channel_list/customizations/uiChannelListCustomizationsChangingStyle','769'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/channel_list/uiChannelListBindingViewModels',
  component: ComponentCreator('/chat/docs/sdk/android/ui/channel_list/uiChannelListBindingViewModels','5d6'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/channel_list/uiChannelListCreatingLayout',
  component: ComponentCreator('/chat/docs/sdk/android/ui/channel_list/uiChannelListCreatingLayout','83b'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/channel_list/uiChannelListHandlingChannelActions',
  component: ComponentCreator('/chat/docs/sdk/android/ui/channel_list/uiChannelListHandlingChannelActions','b2c'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/chat_view/sample_chat_customizations/uiSampleChatCustomizationsChangingComponents',
  component: ComponentCreator('/chat/docs/sdk/android/ui/chat_view/sample_chat_customizations/uiSampleChatCustomizationsChangingComponents','0de'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/chat_view/sample_chat_customizations/uiSampleChatCustomizationsChangingMessageInputView',
  component: ComponentCreator('/chat/docs/sdk/android/ui/chat_view/sample_chat_customizations/uiSampleChatCustomizationsChangingMessageInputView','370'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/chat_view/sample_chat_customizations/uiSampleChatCustomizationsChangingMessagesStyle',
  component: ComponentCreator('/chat/docs/sdk/android/ui/chat_view/sample_chat_customizations/uiSampleChatCustomizationsChangingMessagesStyle','ffd'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/chat_view/uiBindingChatViewModels',
  component: ComponentCreator('/chat/docs/sdk/android/ui/chat_view/uiBindingChatViewModels','020'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/chat_view/uiCreatingChatLayout',
  component: ComponentCreator('/chat/docs/sdk/android/ui/chat_view/uiCreatingChatLayout','a86'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/chat_view/uiHandlingChatActions',
  component: ComponentCreator('/chat/docs/sdk/android/ui/chat_view/uiHandlingChatActions','e40'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsAvatarBitmapFactory',
  component: ComponentCreator('/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsAvatarBitmapFactory','fea'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsFonts',
  component: ComponentCreator('/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsFonts','31c'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsMarkdown',
  component: ComponentCreator('/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsMarkdown','f57'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsNavigator',
  component: ComponentCreator('/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsNavigator','e8b'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsUrlSigner',
  component: ComponentCreator('/chat/docs/sdk/android/ui/global_customizations/chat_ui_customizations/uiGlobalCustomizationsUrlSigner','21e'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/global_customizations/uiGlobalCustomizationsTransformStyle',
  component: ComponentCreator('/chat/docs/sdk/android/ui/global_customizations/uiGlobalCustomizationsTransformStyle','dca'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/uiAttachmentGallery',
  component: ComponentCreator('/chat/docs/sdk/android/ui/uiAttachmentGallery','40e'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/uiMentionListView',
  component: ComponentCreator('/chat/docs/sdk/android/ui/uiMentionListView','66d'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/uiSearchView',
  component: ComponentCreator('/chat/docs/sdk/android/ui/uiSearchView','125'),
  exact: true,
},
{
  path: '/chat/docs/sdk/android/ui/uiSetup',
  component: ComponentCreator('/chat/docs/sdk/android/ui/uiSetup','7d3'),
  exact: true,
},
]
},
{
  path: '/chat/docs/sdk/flutter',
  component: ComponentCreator('/chat/docs/sdk/flutter','411'),
  
  routes: [
{
  path: '/chat/docs/sdk/flutter/',
  component: ComponentCreator('/chat/docs/sdk/flutter/','646'),
  exact: true,
},
]
},
{
  path: '/chat/docs/sdk/ios',
  component: ComponentCreator('/chat/docs/sdk/ios','beb'),
  
  routes: [
{
  path: '/chat/docs/sdk/ios/',
  component: ComponentCreator('/chat/docs/sdk/ios/','d8a'),
  exact: true,
},
]
},
{
  path: '/chat/docs/sdk/react',
  component: ComponentCreator('/chat/docs/sdk/react','b7b'),
  
  routes: [
{
  path: '/chat/docs/sdk/react/',
  component: ComponentCreator('/chat/docs/sdk/react/','6c8'),
  exact: true,
},
]
},
{
  path: '/chat/docs/sdk/reactnative',
  component: ComponentCreator('/chat/docs/sdk/reactnative','771'),
  
  routes: [
{
  path: '/chat/docs/sdk/reactnative/',
  component: ComponentCreator('/chat/docs/sdk/reactnative/','92e'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/client',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/client','222'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/hello_stream_chat',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/hello_stream_chat','123'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/stream_chat_with_navigation',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/stream_chat_with_navigation','b3d'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/Basics/translations',
  component: ComponentCreator('/chat/docs/sdk/reactnative/Basics/translations','604'),
  exact: true,
},
]
},
{
  path: '*',
  component: ComponentCreator('*')
}
];
