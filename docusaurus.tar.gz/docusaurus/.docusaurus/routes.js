
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';
export default [
{
  path: '/chat/docs/sdk/',
  component: ComponentCreator('/chat/docs/sdk/','981'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative',
  component: ComponentCreator('/chat/docs/sdk/reactnative','a8e'),
  
  routes: [
{
  path: '/chat/docs/sdk/reactnative/',
  component: ComponentCreator('/chat/docs/sdk/reactnative/','ce1'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/basics/client',
  component: ComponentCreator('/chat/docs/sdk/reactnative/basics/client','12c'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/basics/hello_stream_chat',
  component: ComponentCreator('/chat/docs/sdk/reactnative/basics/hello_stream_chat','e50'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/basics/stream_chat_with_navigation',
  component: ComponentCreator('/chat/docs/sdk/reactnative/basics/stream_chat_with_navigation','6d6'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/basics/translations',
  component: ComponentCreator('/chat/docs/sdk/reactnative/basics/translations','2ed'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/components/channel',
  component: ComponentCreator('/chat/docs/sdk/reactnative/components/channel','a45'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/components/channellist',
  component: ComponentCreator('/chat/docs/sdk/reactnative/components/channellist','173'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/components/chat',
  component: ComponentCreator('/chat/docs/sdk/reactnative/components/chat','338'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/components/overlayprovider',
  component: ComponentCreator('/chat/docs/sdk/reactnative/components/overlayprovider','2f6'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/guides/custom-attachment',
  component: ComponentCreator('/chat/docs/sdk/reactnative/guides/custom-attachment','817'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/guides/customize-message-actions',
  component: ComponentCreator('/chat/docs/sdk/reactnative/guides/customize-message-actions','c23'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/guides/keyboard',
  component: ComponentCreator('/chat/docs/sdk/reactnative/guides/keyboard','eea'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/guides/livestream-messagelist',
  component: ComponentCreator('/chat/docs/sdk/reactnative/guides/livestream-messagelist','d1b'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/guides/message-customization',
  component: ComponentCreator('/chat/docs/sdk/reactnative/guides/message-customization','805'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/guides/message-input',
  component: ComponentCreator('/chat/docs/sdk/reactnative/guides/message-input','691'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/guides/press-handlers',
  component: ComponentCreator('/chat/docs/sdk/reactnative/guides/press-handlers','a52'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/guides/push-notifications',
  component: ComponentCreator('/chat/docs/sdk/reactnative/guides/push-notifications','ca6'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/object-types/autocompletetriggersettings',
  component: ComponentCreator('/chat/docs/sdk/reactnative/object-types/autocompletetriggersettings','d2d'),
  exact: true,
},
{
  path: '/chat/docs/sdk/reactnative/object-types/message-action',
  component: ComponentCreator('/chat/docs/sdk/reactnative/object-types/message-action','176'),
  exact: true,
},
]
},
{
  path: '*',
  component: ComponentCreator('*')
}
];
