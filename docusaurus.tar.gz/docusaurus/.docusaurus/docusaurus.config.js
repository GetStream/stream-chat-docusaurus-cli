export default {
  "baseUrl": "/chat/docs/sdk/",
  "favicon": "https://getstream.imgix.net/images/favicons/favicon-96x96.png",
  "onBrokenLinks": "warn",
  "onBrokenMarkdownLinks": "warn",
  "organizationName": "GetStream",
  "plugins": [
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "reactnative",
        "path": "../docusaurus/docs/ReactNative",
        "routeBasePath": "reactnative"
      }
    ],
    "@docusaurus/plugin-content-pages",
    "/Users/tatianainama/git/stream-chat-docusaurus-cli/docusaurus/src/symlink-docusaurus"
  ],
  "projectName": "stream-chat",
  "tagline": "Stream Chat official component SDKs",
  "themeConfig": {
    "footer": {
      "copyright": "© Stream.IO, Inc. All Rights Reserved.",
      "links": [
        {
          "items": [
            {
              "href": "https://twitter.com/getstream_io",
              "label": "Twitter"
            }
          ],
          "title": "Community"
        },
        {
          "items": [
            {
              "href": "https://github.com/GetStream",
              "label": "GitHub"
            }
          ],
          "title": "More"
        }
      ],
      "style": "dark"
    },
    "liveCodeBlock": {
      "playgroundPosition": "bottom"
    },
    "navbar": {
      "items": [
        {
          "href": "https://github.com/GetStream",
          "label": "GitHub",
          "position": "right"
        },
        {
          "items": [
            {
              "label": "React Native",
              "to": "reactnative/",
              "type": "doc"
            }
          ],
          "label": "SDK",
          "position": "left"
        },
        {
          "docsPluginId": "reactnative",
          "type": "docsVersionDropdown",
          "position": "left",
          "dropdownItemsBefore": [],
          "dropdownItemsAfter": []
        }
      ],
      "logo": {
        "alt": "stream",
        "src": "img/logo.svg"
      },
      "title": "stream",
      "hideOnScroll": false
    },
    "colorMode": {
      "defaultMode": "light",
      "disableSwitch": false,
      "respectPrefersColorScheme": false,
      "switchConfig": {
        "darkIcon": "🌜",
        "darkIconStyle": {},
        "lightIcon": "🌞",
        "lightIconStyle": {}
      }
    },
    "docs": {
      "versionPersistence": "localStorage"
    },
    "metadatas": [],
    "prism": {
      "additionalLanguages": []
    },
    "hideableSidebar": false
  },
  "themes": [
    [
      "@docusaurus/theme-classic",
      {
        "customCss": [
          "/Users/tatianainama/git/stream-chat-docusaurus-cli/docusaurus/src/css/custom.css"
        ]
      }
    ],
    "@docusaurus/theme-live-codeblock"
  ],
  "title": "Stream Chat - Component SDK Docs",
  "url": "https://getstream.io",
  "baseUrlIssueBanner": true,
  "i18n": {
    "defaultLocale": "en",
    "locales": [
      "en"
    ],
    "localeConfigs": {}
  },
  "onDuplicateRoutes": "warn",
  "customFields": {},
  "presets": [],
  "titleDelimiter": "|",
  "noIndex": false
};