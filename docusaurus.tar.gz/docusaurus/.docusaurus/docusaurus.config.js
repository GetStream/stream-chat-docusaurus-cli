export default {
  "baseUrl": "/chat/docs/sdk/",
  "favicon": "https://getstream.imgix.net/images/favicons/favicon-96x96.png",
  "onBrokenLinks": "warn",
  "onBrokenMarkdownLinks": "warn",
  "organizationName": "GetStream",
  "plugins": [
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "android",
        "path": "../../stream-chat-docusaurus/docusaurus/docs/Android",
        "routeBasePath": "android"
      }
    ],
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "flutter",
        "path": "../../stream-chat-docusaurus/docusaurus/docs/Flutter",
        "routeBasePath": "flutter"
      }
    ],
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "react",
        "path": "../../stream-chat-docusaurus/docusaurus/docs/React",
        "routeBasePath": "react"
      }
    ],
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "reactnative",
        "path": "../../stream-chat-docusaurus/docusaurus/docs/ReactNative",
        "routeBasePath": "reactnative"
      }
    ],
    [
      "@docusaurus/plugin-content-docs",
      {
        "id": "ios",
        "path": "../../stream-chat-docusaurus/docusaurus/docs/iOS",
        "routeBasePath": "ios"
      }
    ],
    "@docusaurus/plugin-content-pages",
    "/Users/lucascorreia/Documents/workspace/getstream/stream-chat-docusaurus-cli/docusaurus/src/symlink-docusaurus"
  ],
  "projectName": "stream-chat",
  "tagline": "Stream Chat official component SDKs",
  "themeConfig": {
    "algolia": {
      "apiKey": "fd1b03de28081b5aa29dbccced4620b9",
      "indexName": "DOCS",
      "appId": "7RY30ISS74",
      "contextualSearch": false,
      "searchParameters": {}
    },
    "footer": {
      "copyright": "© Stream.IO, Inc. All Rights Reserved.",
      "links": [
        {
          "items": [
            {
              "href": "https://twitter.com/getstream_io",
              "label": "Twitter"
            }
          ],
          "title": "Community"
        },
        {
          "items": [
            {
              "href": "https://github.com/GetStream",
              "label": "GitHub"
            }
          ],
          "title": "More"
        }
      ],
      "style": "dark"
    },
    "liveCodeBlock": {
      "playgroundPosition": "bottom"
    },
    "navbar": {
      "items": [
        {
          "href": "https://github.com/GetStream",
          "label": "GitHub",
          "position": "right"
        },
        {
          "items": [
            {
              "label": "Android",
              "to": "android/?language=kotlin",
              "type": "doc"
            },
            {
              "label": "Flutter",
              "to": "flutter/?language=dart",
              "type": "doc"
            },
            {
              "label": "React",
              "to": "react/?language=javascript",
              "type": "doc"
            },
            {
              "label": "React Native",
              "to": "reactnative/?language=javascript",
              "type": "doc"
            },
            {
              "label": "iOS",
              "to": "ios/?language=swift",
              "type": "doc"
            }
          ],
          "label": "SDK",
          "position": "left"
        },
        {
          "docsPluginId": "android",
          "type": "docsVersionDropdown",
          "position": "left",
          "dropdownItemsBefore": [],
          "dropdownItemsAfter": []
        },
        {
          "docsPluginId": "flutter",
          "type": "docsVersionDropdown",
          "position": "left",
          "dropdownItemsBefore": [],
          "dropdownItemsAfter": []
        },
        {
          "docsPluginId": "react",
          "type": "docsVersionDropdown",
          "position": "left",
          "dropdownItemsBefore": [],
          "dropdownItemsAfter": []
        },
        {
          "docsPluginId": "reactnative",
          "type": "docsVersionDropdown",
          "position": "left",
          "dropdownItemsBefore": [],
          "dropdownItemsAfter": []
        },
        {
          "docsPluginId": "ios",
          "type": "docsVersionDropdown",
          "position": "left",
          "dropdownItemsBefore": [],
          "dropdownItemsAfter": []
        }
      ],
      "logo": {
        "alt": "stream",
        "src": "img/logo.svg"
      },
      "title": "stream",
      "hideOnScroll": false
    },
    "colorMode": {
      "defaultMode": "light",
      "disableSwitch": false,
      "respectPrefersColorScheme": false,
      "switchConfig": {
        "darkIcon": "🌜",
        "darkIconStyle": {},
        "lightIcon": "🌞",
        "lightIconStyle": {}
      }
    },
    "docs": {
      "versionPersistence": "localStorage"
    },
    "metadatas": [],
    "prism": {
      "additionalLanguages": []
    },
    "hideableSidebar": false
  },
  "themes": [
    "@docusaurus/theme-classic",
    "@docusaurus/theme-live-codeblock",
    "@docusaurus/theme-search-algolia"
  ],
  "title": "Stream Chat - Component SDK Docs",
  "url": "https://getstream.io",
  "baseUrlIssueBanner": true,
  "i18n": {
    "defaultLocale": "en",
    "locales": [
      "en"
    ],
    "localeConfigs": {}
  },
  "onDuplicateRoutes": "warn",
  "customFields": {},
  "presets": [],
  "titleDelimiter": "|",
  "noIndex": false
};