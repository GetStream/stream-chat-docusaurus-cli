export default [
  require("/Users/tatianainama/git/stream-chat-docusaurus-cli/docusaurus/node_modules/remark-admonitions/styles/infima.css"),
  require("/Users/tatianainama/git/stream-chat-docusaurus-cli/docusaurus/node_modules/remark-admonitions/styles/infima.css"),
  require("/Users/tatianainama/git/stream-chat-docusaurus-cli/docusaurus/node_modules/infima/dist/css/default/default.css"),
  require("/Users/tatianainama/git/stream-chat-docusaurus-cli/docusaurus/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/Users/tatianainama/git/stream-chat-docusaurus-cli/docusaurus/src/css/custom.css"),
];
