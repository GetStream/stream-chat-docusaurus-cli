const cheerio = require('cheerio');
const fetch = require('node-fetch');

module.exports = function (context, options) {
  return {
    name: 'stream-layout-fetch',
    async loadContent() {
      const response = await fetch('https://getstream.io/chat/docs/react/');
      const html = await response.text();
      const $ = cheerio.load(html);

      const links = [];
      const scripts = [];
      const styles = [];

      $('head link').each((_, link) => {
        links.push({
          ...link.attribs,
          href: `https://getstream.io${link.attribs.href}`,
        });
      });

      $('body > script').each((_, script) => {
        if (!script.attribs.src) {
          return;
        }
        scripts.push({
          ...script.attribs,
          src:
            script.attribs.src.startsWith('//') ||
            script.attribs.src.startsWith('http')
              ? script.attribs.src
              : `https://getstream.io${script.attribs.src}`,
        });
      });

      $('head > style').each((_, node) => {
        if (node.type == 'style') {
          styles.push(node.children[0].data);
        }
      });

      $('main > div:nth-child(3)').html('<div id=docusaurus-content />');
      $('main > div:nth-child(2)').html('<div id=docusaurus-header />');

      return {
        links,
        scripts,
        styles,
        body: $('#___gatsby').html(),
      };
    },
    async contentLoaded({ content, actions }) {
      actions.setGlobalData(content);
    },
  };
};
