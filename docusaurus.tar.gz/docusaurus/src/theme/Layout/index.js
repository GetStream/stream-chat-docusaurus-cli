import React from 'react';
import clsx from 'clsx';
import Navbar from '@theme/Navbar';
import LayoutProviders from '@theme/LayoutProviders';
import LayoutHead from '@theme/LayoutHead';
import useKeyboardNavigation from '@theme/hooks/useKeyboardNavigation';
import { usePluginData } from '@docusaurus/useGlobalData';
import './styles.css';
import Head from '@docusaurus/Head';
import parse from 'html-react-parser';

function Layout(props) {
  const { children, wrapperClassName } = props;
  useKeyboardNavigation();
  const { links, body, scripts, styles } = usePluginData('stream-layout-fetch');
  return (
    <LayoutProviders>
      <Head>
        {links.map((props, index) => (
          <link key={index} {...props} />
        ))}

        {styles.map((content, index) => (
          <style type='text/css' key={index}>
            {content}
          </style>
        ))}
      </Head>
      <LayoutHead {...props} />

      <div id='___gatsby'>
        {parse(body, {
          replace: (node) => {
            if (node.attribs && node.attribs.id == 'docusaurus-content') {
              return (
                <div className={clsx('main-wrapper', wrapperClassName)}>
                  {children}
                </div>
              );
            }
            if (node.attribs && node.attribs.id == 'docusaurus-header') {
              return <Navbar />;
            }
          },
        })}
      </div>

      {scripts.map((props, index) => (
        <script key={index} {...props} />
      ))}
    </LayoutProviders>
  );
}

export default Layout;
