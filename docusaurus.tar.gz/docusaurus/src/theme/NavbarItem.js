import React from 'react';
import { useLocation } from '@docusaurus/router';
import OriginalNavBarItem from '@theme-original/NavbarItem';

export default function NavbarItem(props) {
  const { docsPluginId, items, label, type } = props;
  const { pathname } = useLocation();

  if (
    type === 'docsVersionDropdown' &&
    pathname
      .replace(' ', '')
      .search(new RegExp(`^/chat/docs/sdk/${docsPluginId}(/?|/.*)`, 'g')) === -1
  ) {
    return null;
  }

  if (label === 'SDK' && pathname !== '/') {
    const SDK = items.find(
      (item) => pathname.search(new RegExp(`^${item.to}(/?|/.*)`, 'g')) !== -1
    );
    return (
      <>
        <OriginalNavBarItem {...props} label={SDK.label} />
      </>
    );
  }

  return (
    <>
      <OriginalNavBarItem {...props} />
    </>
  );
}
